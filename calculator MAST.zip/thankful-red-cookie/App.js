import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, Alert } from 'react-native';

export default function App() {
  const [num1, setNum1] = useState('');
  const [num2, setNum2] = useState('');
  const [result, setResult] = useState(null);

  // Function to validate inputs
  const validateInputs = () => {
    if (num1 === '' || isNaN(num1)) {
      Alert.alert('Invalid input', 'Please enter a valid number for the first input.');
      return false;
    }
    if (num2 === '' || isNaN(num2)) {
      Alert.alert('Invalid input', 'Please enter a valid number for the second input.');
      return false;
    }
    return true;
  };

  const handleCalculation = (type) => {
    if (!validateInputs()) return;

    const number1 = parseFloat(num1);
    const number2 = parseFloat(num2);
    let calcResult;

    switch (type) {
      case 'add':
        calcResult = number1 + number2;
        break;
      case 'subtract':
        calcResult = number1 - number2;
        break;
      case 'multiply':
        calcResult = number1 * number2;
        break;
      case 'divide':
        if (number2 === 0) {
          Alert.alert('Error', 'Cannot divide by zero!');
          return;
        }
        calcResult = number1 / number2;
        break;
      case 'power':
        calcResult = Math.pow(number1, number2);
        break;
      case 'sqrt':
        if (number1 < 0) {
          Alert.alert('Error', 'Cannot calculate square root of a negative number!');
          return;
        }
        calcResult = Math.sqrt(number1);
        break;
      default:
        calcResult = 0;
    }

    setResult(calcResult);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Calculator App</Text>
      
      <TextInput
        style={styles.input}
        placeholder="Enter first number"
        keyboardType="numeric"
        onChangeText={setNum1}
        value={num1}
      />
      
      <TextInput
        style={styles.input}
        placeholder="Enter second number"
        keyboardType="numeric"
        onChangeText={setNum2}
        value={num2}
      />
      
      <View style={styles.buttonContainer}>
        <Button title="Add" onPress={() => handleCalculation('add')} />
        <Button title="Subtract" onPress={() => handleCalculation('subtract')} />
        <Button title="Multiply" onPress={() => handleCalculation('multiply')} />
        <Button title="Divide" onPress={() => handleCalculation('divide')} />
        <Button title="To the Power Of" onPress={() => handleCalculation('power')} />
        <Button title="Square Root" onPress={() => handleCalculation('sqrt')} />
      </View>

      {result !== null && (
        <Text style={styles.result}>Result: {result}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#d3d3d3',
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    marginBottom: 10,
    width: '80%',
    paddingHorizontal: 10,
  },
  buttonContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginVertical: 10,
  },
 
  result: {
    marginTop: 20,
    fontSize: 20,
  },
});
